# Initializing parameters
##############################################################################

# Package for k-NN

library(kknn)
#library(e1071)
library(kernlab)
library(randomForest)
library(C50)
library(RSNNS)

# Package for R compiling

library(compiler)

cmp_kknn=cmpfun(kknn)
cmp_mlp=cmpfun(mlp)
cmp_ksvm=cmpfun(ksvm)
enableJIT(3)

# Selected data set

data=dataNet # Change it inside loop too

# Folds for the selected data set

folds=foldsNet

# Inputs

inputs=list(c("Depth_m","qt_MPa","fs_kPa","u_kPa"))
inputs=append(inputs,list(c("Depth_m","Qt1","Fr_p","Bq")))
inputs=append(inputs,list(c("Depth_m","Qtn","Fr_p","U2")))

# Outputs

outputs=c("SBTn","MSBTn")

# Weighting function for KNN

mode="gaussian"

# Kernel function for SVM

#svmMode="rbfdot"
svmMode="polydot"
#svmMode="laplacedot"

# Initializing matrix with "k" values obtained for each testing case and its accucary associated

kval=matrix(0,10,1)
colnames(kval)=c("accuracy")

rn=c()

for(i in 1:10){
  rn=rbind(rn,as.character(i))
}

rownames(kval)=rn

# Initializing list with kval matrices

lokval=list()

# Initializing list with kval mean

lokvalm=list()

# Initializing list with kval standard deviation

lokvalsd=list()

# Initializing list of confusion matrices

loconf=list()

# Initializing list of mean confusion matrices

loconfm=list()

# Initializing matrix with "k" values obtained for each testing case and its accucary associated

ann_kval=matrix(0,10,4)
colnames(ann_kval)=c("n","m","iterations","accuracy")

rn=c()

for(i in 1:10){
  rn=rbind(rn,as.character(i))
}

rownames(ann_kval)=rn

# Initializing list with kval matrices

ann_lokval=list()

# Initializing list with kval mean

ann_lokvalm=list()

# Initializing list with kval standard deviation

ann_lokvalsd=list()

# Initializing list of confusion matrices

ann_loconf=list()

# Initializing list of mean confusion matrices

ann_loconfm=list()

# Initializing matrix with "k" values obtained for each testing case and its accucary associated

dt_kval=matrix(0,10,2)
colnames(dt_kval)=c("trials","accuracy")

rn=c()

for(i in 1:10){
  rn=rbind(rn,as.character(i))
}

rownames(dt_kval)=rn

# Initializing list with kval matrices

dt_lokval=list()

# Initializing list with kval mean

dt_lokvalm=list()

# Initializing list with kval standard deviation

dt_lokvalsd=list()

# Initializing list of confusion matrices

dt_loconf=list()

# Initializing list of mean confusion matrices

dt_loconfm=list()

# Initializing matrix with "k" values obtained for each testing case and its accucary associated

rf_kval=matrix(0,10,1)
colnames(rf_kval)=c("accuracy")

rn=c()

for(i in 1:10){
  rn=rbind(rn,as.character(i))
}

rownames(rf_kval)=rn

# Initializing list with kval matrices

rf_lokval=list()

# Initializing list with kval mean

rf_lokvalm=list()

# Initializing list with kval standard deviation

rf_lokvalsd=list()

# Initializing list of confusion matrices

rf_loconf=list()

# Initializing list of mean confusion matrices

rf_loconfm=list()

# Initializing matrix with "k" values obtained for each testing case and its accucary associated

svm_kval=matrix(0,10,1)
colnames(svm_kval)=c("accuracy")

rn=c()

for(i in 1:10){
  rn=rbind(rn,as.character(i))
}

rownames(svm_kval)=rn

# Initializing list with kval matrices

svm_lokval=list()

# Initializing list with kval mean

svm_lokvalm=list()

# Initializing list with kval standard deviation

svm_lokvalsd=list()

# Initializing list of confusion matrices

svm_loconf=list()

# Initializing list of mean confusion matrices

svm_loconfm=list()

# Initializing matrix with "k" values obtained for each testing case and its accucary associated

knn_kval=matrix(0,10,2)
colnames(knn_kval)=c("k","accuracy")

rn=c()

for(i in 1:10){
  rn=rbind(rn,as.character(i))
}

rownames(knn_kval)=rn

# Initializing list with kval matrices

knn_lokval=list()

# Initializing list with kval mean

knn_lokvalm=list()

# Initializing list with kval standard deviation

knn_lokvalsd=list()

# Initializing list of confusion matrices

knn_loconf=list()

# Initializing list of mean confusion matrices

knn_loconfm=list()

# Initializing list of training datasets

lotrain=list()

# Initializing list of testing datasets

lotest=list()

# Initializing list of validation datasets

lovalid=list()

# Initializing list of training datasets

lotrainb=list()

# Initializing list of testing datasets

lotestb=list()

# Initializing list of validation datasets

lovalidb=list()

# Initializing list of training datasets

lomtrain=list()

# Initializing list of testing datasets

lomtest=list()

# Initializing list of validation datasets

lomvalid=list()

# Initializing list of training datasets

lomtrainb=list()

# Initializing list of testing datasets

lomtestb=list()

# Initializing list of validation datasets

lomvalidb=list()

# Initializing list of SVM models

svm_lomodels=list()

# Initializing list of ANN weights matrices

ann_lowm=list()

# Initializing DT list of importances by usage

loimpu=list()

# Initializing DT list of mean importances by usage

loimpum=list()

# Initializing DT list of importances by split

loimps=list()

# Initializing DT list of mean importances by split

loimpsm=list()

# Initializing RF list of importances by Mean Decrease Gini

loimp=list()

# Initializing RF list of mean importances by Mean Decrease Gini

loimpm=list()

# Initializing list of best "n"

lon=list()

# Initializing list of best "m"

lom=list()

# Initializing list of best "k"

lokvalk=list()

# Initializing list of kernel parameters

lokpar=list()

# Initializing list of mean kernel parameters

lokparm=list()

# Initializing counter

counter=0

# MM application
##############################################################################

# For each output

for(out in outputs){
  
  # For each inputs set
  
  for(inpCase in 1:length(inputs)){
    
    # Selecting input features
    
    inp=inputs[[inpCase]]
    
    # Atualizing data set
    
    data=dataNet
    
    # Eliminating other features from data
    
    datancol=ncol(data)
    idxr=c()
    
    for(i in 1:datancol){
      at=colnames(data)[i]
      if(length(inp[inp==at])==0 && at!=out){
        idxr=append(idxr,i)
      }
    }
    
    data=data[,-idxr]
    
    # Defining formula
    
    form=paste(inp,collapse="+")
    form=as.formula(paste(append(out,form),collapse="~"))
    
    #10-fold cross-validation technique
    
    for(i in 1:10){
      
      # Counting
      
      counter=counter+1
      
      # Testing case
      
      cat("\nTesting case:",i,"\n\n")
      
      # Test data set as matrix

      mtest=as.matrix(data[folds[[i]],])

      # Validation data set as matrix

      mvalid=as.matrix(data[folds[[validFolds[i]]],])

      # Training data set as matrix

      mtrain=as.matrix(data[-append(folds[[i]],folds[[validFolds[i]]]),])

      # Removing Robertson's (1991) class 0

      if(out=="SBTn"){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }

      # Normalization by rescaling

      minVal=c()

      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }

      # Data frame with minimum values

      minVal=as.matrix(minVal)
      colnames(minVal)=inp

      maxVal=c()

      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }

      # Data frame with maximum values

      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp

      # Normalizing

      for(j in 1:length(inp)){

        mini=minVal[j]
        maxi=maxVal[j]

        cat("Normalizing",inp[j],"\n")

        for(obj in 1:nrow(mtrain)){
          t=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
          mtrain[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
        for(obj in 1:nrow(mvalid)){
          t=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
          mvalid[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
        for(obj in 1:nrow(mtest)){
          t=(mtest[obj,inp[j]]-mini)/(maxi-mini)
          mtest[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
      }

      # Statistical marks for pre-filtering

      q1=c()
      q3=c()

      for(class in sort(unique(mtrain[,out]))){
        auxq1=c()
        auxq3=c()
        for(at in inp[inp!="Depth_m"]){

          # First quartile

          auxq1=append(auxq1,quantile(mtrain[mtrain[,out]==class,at])[2])

          # Third quartile

          auxq3=append(auxq3,quantile(mtrain[mtrain[,out]==class,at])[4])

        }
        q1=cbind(q1,auxq1)
        q3=cbind(q3,auxq3)
      }


      # Interquartil interval

      iq=q3-q1

      # Formating

      q1=t(as.matrix(q1))
      colnames(q1)=inp[inp!="Depth_m"]
      rownames(q1)=sort(unique(mtrain[,out]))

      q3=t(as.matrix(q3))
      colnames(q3)=inp[inp!="Depth_m"]
      rownames(q3)=sort(unique(mtrain[,out]))

      iq=t(as.matrix(iq))
      colnames(iq)=inp[inp!="Depth_m"]
      rownames(iq)=sort(unique(mtrain[,out]))

      # Data cleaning

      removed=0
      idx=c()

      # Pre-filtering

      cat("\nPre-filtering\n")

      for(obj in 1:nrow(mtrain)){
        class=as.character(mtrain[obj,out])
        for(at in inp[inp!="Depth_m"]){
          if(mtrain[obj,at]>q3[class,at]+1.5*iq[class,at]
             || mtrain[obj,at]<q1[class,at]-1.5*iq[class,at]){
            if(length(idx)==0 || obj!=idx[length(idx)]){
              idx=append(idx,obj)
              #cat("Pre-filtered:",length(idx),"\n")
              #cat("Object:",obj,"\n\n")
            }
          }
        }
      }

      # Data frame of test data set

      test=as.data.frame(mtest)

      # Data frame of validation data set

      valid=as.data.frame(mvalid)

      # Data frame of training data set

      train=as.data.frame(mtrain)

      # Converting outputs of the data frames into factors

      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])

      # Filtering

      cat("\nFiltering\n")

      filt=0

      for(obj in 1:length(idx)){
        fitTrain <- cmp_kknn(formula=form,
                         train=train[-idx[obj],],
                         test=train[idx[obj],],
                         k=1,
                         distance=2,
                         kernel="rectangular",
                         scale=FALSE)

        pred=fitTrain$fitted.values

        filt=filt+1

        # Remove object if it was misclassified

        if(pred!=train[idx[obj],out]){
          train=train[-idx[obj],]
          idx=idx-1
          removed=removed+1
          #cat("Filtered:",removed,"\n\n")
          #cat("Pre-filtered object:",filt,"\n")
        }
      }

      # Training data set as matrix

      train[,out]=as.numeric(as.character(train[,out]))
      mtrain=as.matrix(train)

      # Initializing sets for balanced training set

      mtrainb=mtrain
      mtestb=mtest
      mvalidb=mvalid

      # Proportion check

      cat("\nProportion check\n\n")

      prop=c()

      for(j in sort(unique(mtrainb[,out]))){
        prop=append(prop,nrow(mtrainb[mtrainb[,out]==j,]))
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }

      cat("\nBalancing\n\n")

      # Number of elements in the minority class

      minProp=min(prop)

      # Total number of elements by class

      nTot=max(1000,2*minProp)

      # Balancing

      for(j in sort(unique(mtrainb[,out]))){
        mtrainClass=mtrainb[mtrainb[,out]==j,]
        numEl=nrow(mtrainClass)
        if(numEl>nTot){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),numEl-nTot)
          mtrainb=rbind(mtrainb[mtrainb[,out]!=j,],mtrainClass[-objIdx,])
        }
        else if(numEl<nTot){
          for(p in 1:(nTot-numEl)){
            set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
            objIdx=sample(nrow(mtrainClass),length(inp)+1)
            obj=c()
            for(at in colnames(mtrainb)){
              if(at==out){
                obj=append(obj,j)
              }else{
                obj=append(obj,mean(mtrainClass[objIdx,at]))
              }
            }
            mtrainb=rbind(mtrainb,obj)
          }
        }
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }

      # Normalization of unbalanced training set

      cat("\nUnbalanced training set normalization\n\n")

      minVal=c()

      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }

      # Data frame with minimum values

      minVal=as.matrix(minVal)
      colnames(minVal)=inp

      maxVal=c()

      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }

      # Data frame with maximum values

      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp

      # Normalizing

      for(j in 1:length(inp)){

        mini=minVal[j]
        maxi=maxVal[j]

        cat("Normalizing",inp[j],"\n")

        for(obj in 1:nrow(mtrain)){
          mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalid)){
          mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtest)){
          mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
        }
      }

      # Normalization of balanced training set

      cat("\nBalanced training set normalization\n\n")

      minVal=c()

      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrainb[,inp[j]]))
      }

      # Data frame with minimum values

      minVal=as.matrix(minVal)
      colnames(minVal)=inp

      maxVal=c()

      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrainb[,inp[j]]))
      }

      # Data frame with maximum values

      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp

      # Normalizing

      for(j in 1:length(inp)){

        mini=minVal[j]
        maxi=maxVal[j]

        cat("Normalizing",inp[j],"\n")

        for(obj in 1:nrow(mtrainb)){
          mtrainb[obj,inp[j]]=(mtrainb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalidb)){
          mvalidb[obj,inp[j]]=(mvalidb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtestb)){
          mtestb[obj,inp[j]]=(mtestb[obj,inp[j]]-mini)/(maxi-mini)
        }
      }

      # Data frame of test data set

      test=as.data.frame(mtest)

      # Data frame of validation data set

      valid=as.data.frame(mvalid)

      # Data frame of unbalanced training data set

      train=as.data.frame(mtrain)

      # Data frame of the data sets for balanced training set

      testb=as.data.frame(mtestb)
      validb=as.data.frame(mvalidb)
      trainb=as.data.frame(mtrainb)

      # Converting outputs of the data frames into factors

      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])

      trainb[,out]=as.factor(trainb[,out])
      validb[,out]=as.factor(validb[,out])
      testb[,out]=as.factor(testb[,out])

      # # Saving datasets
      # 
      # lotrain[[length(lotrain)+1]]=train
      # lotest[[length(lotest)+1]]=test
      # lovalid[[length(lovalid)+1]]=valid
      # 
      # lotrainb[[length(lotrainb)+1]]=trainb
      # lotestb[[length(lotestb)+1]]=testb
      # lovalidb[[length(lovalidb)+1]]=validb
      # 
      # lomtrain[[length(lomtrain)+1]]=mtrain
      # lomtest[[length(lomtest)+1]]=mtest
      # lomvalid[[length(lomvalid)+1]]=mvalid
      # 
      # lomtrainb[[length(lomtrainb)+1]]=mtrainb
      # lomtestb[[length(lomtestb)+1]]=mtestb
      # lomvalidb[[length(lomvalidb)+1]]=mvalidb
      
      # # Loading pre-processed datasets
      # 
      # train=lotrain[[counter]]
      # test=lotest[[counter]]
      # valid=lovalid[[counter]]
      # 
      # trainb=lotrainb[[counter]]
      # testb=lotestb[[counter]]
      # validb=lovalidb[[counter]]
      # 
      # mtrain=lomtrain[[counter]]
      # mtest=lomtest[[counter]]
      # mvalid=lomvalid[[counter]]
      # 
      # mtrainb=lomtrainb[[counter]]
      # mtestb=lomtestb[[counter]]
      # mvalidb=lomvalidb[[counter]]
      
      # Modifying with one-to-c (canonic) encoding
      
      classZero=min(unique(mtrain[,out]))
      nclass=max(unique(mtrain[,out]))
      iniCols=ncol(mtrain)
      mtrain_ann=mtrain
      mtest_ann=mtest
      mvalid_ann=mvalid
      mtrainb_ann=mtrainb
      mtestb_ann=mtestb
      mvalidb_ann=mvalidb
      for(j in classZero:nclass){
        mtrain_ann=cbind(mtrain_ann,matrix(0,nrow(mtrain_ann),1))
        colnames(mtrain_ann)[length(colnames(mtrain_ann))]=paste("c",as.character(j),sep="")
        mvalid_ann=cbind(mvalid_ann,matrix(0,nrow(mvalid_ann),1))
        colnames(mvalid_ann)[length(colnames(mvalid_ann))]=paste("c",as.character(j),sep="")
        mtest_ann=cbind(mtest_ann,matrix(0,nrow(mtest_ann),1))
        colnames(mtest_ann)[length(colnames(mtest_ann))]=paste("c",as.character(j),sep="")
        mtrainb_ann=cbind(mtrainb_ann,matrix(0,nrow(mtrainb_ann),1))
        colnames(mtrainb_ann)[length(colnames(mtrainb_ann))]=paste("c",as.character(j),sep="")
        mvalidb_ann=cbind(mvalidb_ann,matrix(0,nrow(mvalidb_ann),1))
        colnames(mvalidb_ann)[length(colnames(mvalidb_ann))]=paste("c",as.character(j),sep="")
        mtestb_ann=cbind(mtestb_ann,matrix(0,nrow(mtestb_ann),1))
        colnames(mtestb_ann)[length(colnames(mtestb_ann))]=paste("c",as.character(j),sep="")
      }
      for(j in 1:nrow(mtrain_ann)){
        mtrain_ann[j,iniCols+mtrain_ann[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mtest_ann)){
        mtest_ann[j,iniCols+mtest_ann[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mvalid_ann)){
        mvalid_ann[j,iniCols+mvalid_ann[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mtrainb_ann)){
        mtrainb_ann[j,iniCols+mtrainb_ann[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mtestb_ann)){
        mtestb_ann[j,iniCols+mtestb_ann[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mvalidb_ann)){
        mvalidb_ann[j,iniCols+mvalidb_ann[j,out]+1-classZero]=1
      }
      mtrain_ann=mtrain_ann[,colnames(mtrain_ann)!=out]
      mtest_ann=mtest_ann[,colnames(mtest_ann)!=out]
      mvalid_ann=mvalid_ann[,colnames(mvalid_ann)!=out]
      mtrainb_ann=mtrainb_ann[,colnames(mtrainb_ann)!=out]
      mtestb_ann=mtestb_ann[,colnames(mtestb_ann)!=out]
      mvalidb_ann=mvalidb_ann[,colnames(mvalidb_ann)!=out]
      iniCols=iniCols-1
      
      # New formula
      
      fout=colnames(mtrain)[iniCols+1]
      
      for(j in (classZero+1):nclass){
        fout=paste(fout,colnames(mtrain)[iniCols+j+1-classZero],sep="+")
      }
      
      formula_ann=paste(fout,as.character(form)[length(as.character(form))],sep="~")
      
      formula_ann=as.formula(formula_ann)
      
      # From matrix into dataframe
      
      train_ann=as.data.frame(mtrain_ann)
      rownames(train_ann)=NULL
      valid_ann=as.data.frame(mvalid_ann)
      rownames(valid_ann)=NULL
      test_ann=as.data.frame(mtest_ann)
      rownames(test_ann)=NULL
      
      trainb_ann=as.data.frame(mtrainb_ann)
      rownames(trainb_ann)=NULL
      validb_ann=as.data.frame(mvalidb_ann)
      rownames(validb_ann)=NULL
      testb_ann=as.data.frame(mtestb_ann)
      rownames(testb_ann)=NULL
      
      rownames(train)=NULL
      rownames(test)=NULL
      rownames(valid)=NULL
      
      rownames(trainb)=NULL
      rownames(testb)=NULL
      rownames(validb)=NULL
      
      # Training ANN
      
      # Determining the maximum number of iterations
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean precision
      
      prevmp=0
      
      # Initializing number of neurons on the first hidden layer
      
      it=200
      
      while(cont){
        
        cat("\nTraining neural network with ", it," iterations\n")
        
        # Constructing the model
        
        model = cmp_mlp(x=mtrainb_ann[,c(1:iniCols)],y=mtrainb_ann[,-c(1:iniCols)],size=c(nclass-classZero+1),maxit=it,outputActFunc="Act_Logistic")
        
        # Predictions
        
        predictions=predict(model,mvalidb_ann[,1:iniCols])
        preds=predictions
        for(p in 1:nrow(preds)){
          for(q in 1:ncol(preds)){
            if(preds[p,q]==max(preds[p,])){
              preds[p,q]=1
            }else{
              preds[p,q]=0
            }
          }
        }
        
        # Calculating accuracy
        
        mp=0
        
        for(j in classZero:nclass){
          mp=mp+sum(preds[preds[,j+1-classZero]==mvalidb_ann[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalidb_ann[,iniCols+j+1-classZero])
        }
        
        mp=mp/(nclass-classZero+1)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        if(mp < prevmp){
          cont=0
          it=it-200
        }else{
          it=it+200
          prevmp=mp
        }
      }
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean precision
      
      prevmp1=0
      
      # Initializing number of neurons on the first hidden layer
      
      n=1#nclass-classZero+1
      
      # Initializing the best number of neurons
      
      nmax=1#nclass-classZero+1
      
      # Training
      
      while(cont){
        
        cat("\nTraining neural network for n =",n," and m =", 0, "\n")
        
        # Constructing the model
        
        model = cmp_mlp(x=mtrainb_ann[,c(1:iniCols)],y=mtrainb_ann[,-c(1:iniCols)],size=c(n),maxit=it,outputActFunc="Act_Logistic")
        
        # Predictions
        
        predictions=predict(model,mvalidb_ann[,1:iniCols])
        preds=predictions
        for(p in 1:nrow(preds)){
          for(q in 1:ncol(preds)){
            if(preds[p,q]==max(preds[p,])){
              preds[p,q]=1
            }else{
              preds[p,q]=0
            }
          }
        }
        
        # Calculating accuracy
        
        mp=0
        
        for(j in classZero:nclass){
          mp=mp+sum(preds[preds[,j+1-classZero]==mvalidb_ann[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalidb_ann[,iniCols+j+1-classZero])
        }
        
        mp=mp/(nclass-classZero+1)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        # if(mp < prevmp1){
        #   cont=0
        #   n=n-1
        # }else{
        #   n=n+1
        #   prevmp1=mp
        # }
        
        if(mp > prevmp1){
          prevmp1=mp
          nmax=n
        }
        
        if(n==2*(nclass-classZero+1)){
          cont=0
        }else{
          n=n+1
        }
      }
      
      n=nmax
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean recall
      
      prevmp2=0
      
      # Initializing number of neurons on the second hidden layer
      
      m=1#nclass-classZero+1
      
      # Initializing the best number of neurons
      
      mmax=1#nclass-classZero+1
      
      # Training
      
      while(cont){
        
        cat("\nTraining neural network for n =",n," and m =", m, "\n")
        
        # Constructing the model
        
        model = cmp_mlp(x=mtrainb_ann[,c(1:iniCols)],y=mtrainb_ann[,-c(1:iniCols)],size=c(n,m),maxit=it,hiddenActFunc="Act_Logistic",outputActFunc="Act_Logistic")
        
        # Predictions
        
        predictions=predict(model,mvalidb_ann[,1:iniCols])
        preds=predictions
        for(p in 1:nrow(preds)){
          for(q in 1:ncol(preds)){
            if(preds[p,q]==max(preds[p,])){
              preds[p,q]=1
            }else{
              preds[p,q]=0
            }
          }
        }
        
        # Calculating accuracy
        
        mp=0
        
        for(j in classZero:nclass){
          mp=mp+sum(preds[preds[,j+1-classZero]==mvalidb_ann[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalidb_ann[,iniCols+j+1-classZero])
        }
        
        mp=mp/(nclass-classZero+1)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        # if(mp < prevmp2){
        #   cont=0
        #   m=m-1
        # }else{
        #   m=m+1
        #   prevmp2=mp
        # }
        
        if(mp > prevmp2){
          prevmp2=mp
          mmax=m
        }
        
        if(m==2*(nclass-classZero+1)){
          cont=0
        }else{
          m=m+1
        }
      }
      
      # Using the second hidden layer just if it improves the model
      
      if(prevmp2<=prevmp1){
        m=0
      }else{
        m=mmax
      }
      
      # Pre-testing the balanced set for KNN
      
      fitValidb <- kknn(formula=form,
                        train=trainb,
                        test=validb,
                        k=3,
                        distance=2,
                        kernel=mode,
                        scale=FALSE)
      
      # Calculating accuracy (mean recall)
      
      confb=table(fitValidb$fit,validb[,out])
      
      mpb=0
      
      for(j in colnames(confb)){
        if(sum(confb[,j])!=0&&sum(confb[rownames(confb)==j,])!=0){
          mpb=mpb+confb[j,j]/sum(confb[,j])
        }
      }
      
      mpb=mpb/ncol(confb)
      
      cat("\nKNN balanced training set pre-test accuracy:",mpb*100,"\n\n")
      
      # Pre-testing the unbalanced set
      
      fitValid <- kknn(formula=form,
                       train=train,
                       test=valid,
                       k=3,
                       distance=2,
                       kernel=mode,
                       scale=FALSE)
      
      # Calculating accuracy (mean recall)
      
      conf=table(fitValid$fit,valid[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        if(sum(conf[,j])!=0&&sum(conf[rownames(conf)==j,])!=0){
          mp=mp+conf[j,j]/sum(conf[,j])
        }
      }
      
      mp=mp/ncol(conf)
      
      cat("KNN unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      
      if(mpb>mp){
        knn_train=trainb
        knn_test=testb
        knn_valid=validb
        cat("Using balanced set!\n\n")
      }
      else{
        knn_train=train
        knn_test=test
        knn_valid=valid
        cat("Using unbalanced set!\n\n")
      }
      
      # Training KNN
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean recall
      
      prevmp=0
      
      # Initializing "k" parameter of k-NN (k=2*k-1)
      
      k=1
      
      while(cont){
        
        cat("\nTraining KNN for k =",2*k-1,"\n")
        
        # Training
        
        fitValid <- kknn(formula=form,
                         train=knn_train,
                         test=knn_valid,
                         k=2*k-1,
                         distance=2,
                         kernel=mode,
                         scale=FALSE)
        
        # Calculating accuracy (mean recall)
        
        conf=table(fitValid$fit,knn_valid[,out])
        
        mp=0
        
        for(j in colnames(conf)){
          if(sum(conf[,j])!=0&&sum(conf[rownames(conf)==j,])!=0){
            mp=mp+conf[j,j]/sum(conf[,j])
          }
        }
        
        mp=mp/ncol(conf)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        if(mp < prevmp){
          cont=0
          k=k-1
        }else{
          k=k+1
          prevmp=mp
        }
      }
      
      # Pre-testing the balanced set
      
      # Constructing the model
      
      rownames(trainb)=NULL
      
      fit <- C5.0(form,data=trainb,trials=nclass-classZero+1)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, validb, type = "class")
      
      # Calculating accuracy (mean precision)
      
      confb=table(preds,validb[,out])
      
      mpb=0
      
      for(j in colnames(confb)){
        if(sum(confb[,j])!=0&&sum(confb[rownames(confb)==j,])!=0){
          mpb=mpb+confb[j,j]/sum(confb[,j])
        }
      }
      
      mpb=mpb/ncol(confb)
      
      cat("\nDT balanced training set pre-test accuracy:",mpb*100,"\n\n")
      
      # Pre-testing the unbalanced set
      
      # Constructing the model
      
      rownames(train)=NULL
      
      fit <- C5.0(form,data=train,trials=nclass-classZero+1)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, valid, type = "class")
      
      # Calculating accuracy (mean precision)
      
      conf=table(preds,valid[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        if(sum(conf[,j])!=0&&sum(conf[rownames(conf)==j,])!=0){
          mp=mp+conf[j,j]/sum(conf[,j])
        }
      }
      
      mp=mp/ncol(conf)
      
      cat("DT unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      
      if(mpb>mp){
        dt_train=trainb
        dt_test=testb
        dt_valid=validb
        cat("Using balanced set!\n\n")
      }
      else{
        dt_train=train
        dt_test=test
        dt_valid=valid
        cat("Using unbalanced set!\n\n")
      }
      
      # Training DT
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean precision
      
      prevmp=0
      
      # Initializing number of trees
      
      t=nclass-classZero+1
      
      while(cont&&t<100){
        
        cat("\nTraining decision trees for",t,"trees\n")
        
        # Training
        
        # Constructing the model
        
        fit <- C5.0(form,data=dt_train,trials=t)
        #plot(fit)
        
        # Predicting
        
        preds <- predict(fit, dt_valid, type = "class")
        
        # Calculating accuracy (mean precision)
        
        conf=table(preds,dt_valid[,out])
        
        mp=0
        
        for(j in colnames(conf)){
          if(sum(conf[,j])!=0&&sum(conf[rownames(conf)==j,])!=0){
            mp=mp+conf[j,j]/sum(conf[,j])
          }
        }
        
        mp=mp/ncol(conf)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        if(mp < prevmp){
          cont=0
          t=t-(nclass-classZero+1)
        }else{
          t=t+(nclass-classZero+1)
          prevmp=mp
        }
      }
      
      # Pre-testing the balanced set for RF
      
      # Constructing the model
      
      rownames(trainb)=NULL
      
      fit <- randomForest(form,data=trainb,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, validb, type = "class")
      
      # Calculating accuracy (mean precision)
      
      confb=table(preds,validb[,out])
      
      mpb=0
      
      for(j in colnames(confb)){
        if(sum(confb[,j])!=0&&sum(confb[rownames(confb)==j,])!=0){
          mpb=mpb+confb[j,j]/sum(confb[,j])
        }
      }
      
      mpb=mpb/ncol(confb)
      
      cat("\nRF balanced training set pre-test accuracy:",mpb*100,"\n\n")
      
      # Pre-testing the unbalanced set for RF
      
      # Constructing the model
      
      rownames(train)=NULL
      
      fit <- randomForest(form,data=train,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, valid, type = "class")
      
      # Calculating accuracy (mean precision)
      
      conf=table(preds,valid[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        if(sum(conf[,j])!=0&&sum(conf[rownames(conf)==j,])!=0){
          mp=mp+conf[j,j]/sum(conf[,j])
        }
      }
      
      mp=mp/ncol(conf)
      
      cat("RF unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      
      if(mpb>mp){
        rf_train=trainb
        rf_test=testb
        rf_valid=validb
        cat("Using balanced set!\n\n")
      }
      else{
        rf_train=train
        rf_test=test
        rf_valid=valid
        cat("Using unbalanced set!\n\n")
      }
      
      if(svmMode=="polydot"){
        cat("\nTraining\n\n")
        
        deg=1
        
        scl=1
        
        prevmp1=0
        
        prevoffs=1
        
        cont1=1
        
        while(cont1){
          
          cont2=1
          
          offs=1
          
          prevmp2=0
          
          while(cont2){
            
            # Constructing the model
            
            model = ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=trainb,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=list(degree=deg,scale=scl,offset=offs))
            
            # Predictions
            
            preds=predict(model,validb[,colnames(validb)!=out])
            
            # Calculating accuracy (mean recall)
            
            conf=table(preds,validb[,out])
            
            mp=0
            
            for(j in colnames(conf)){
              if(sum(conf[,j])!=0&&sum(conf[rownames(conf)==j,])!=0){
                mp=mp+conf[j,j]/sum(conf[,j])
              }
            }
            
            mp=mp/ncol(conf)
            
            cat("Accuracy with degree =",deg,"scale =",scl,"and offset =",offs,":",mp*100,"%\n\n")
            
            if(mp>prevmp2){
              offs=offs+1
              prevmp2=mp
            }else{
              offs=offs-1
              cont2=0
            }
          }
          
          if(prevmp2>prevmp1){
            deg=deg+1
            prevmp1=prevmp2
            prevoffs=offs
          }else{
            deg=deg-1
            offs=prevoffs
            cont1=0
          }
        }
        
        cont1=1
        
        scl=2
        
        while(cont1){
          
          # Constructing the model
          
          model = ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=trainb,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=list(degree=deg,scale=scl,offset=offs))
          
          # Predictions
          
          preds=predict(model,validb[,colnames(validb)!=out])
          
          # Calculating accuracy (mean recall)
          
          conf=table(preds,validb[,out])
          
          mp=0
          
          for(j in colnames(conf)){
            if(sum(conf[,j])!=0&&sum(conf[rownames(conf)==j,])!=0){
              mp=mp+conf[j,j]/sum(conf[,j])
            }
          }
          
          mp=mp/ncol(conf)
          
          cat("Accuracy with degree =",deg,"scale =",scl,"and offset =",offs,":",mp*100,"%\n\n")
          
          if(mp>prevmp1){
            scl=scl+1
            prevmp1=mp
          }else{
            scl=scl-1
            cont1=0
          }
        }
        kparam=list(deg,scl,offs)
        lokpar[[length(lokpar)+1]]=c(deg,scl,offs)
      }else{
        kparam="automatic"
      }
      
      cat("\nTesting\n\n")
      
      # Testing
      
      # Constructing the models for the multiple model
      
      if(m!=0){
        ann_model = cmp_mlp(x=mtrainb_ann[,c(1:iniCols)],y=mtrainb_ann[,-c(1:iniCols)],size=c(n,m),maxit=it,outputActFunc="Act_Logistic")
      }else{
        ann_model = cmp_mlp(x=mtrainb_ann[,c(1:iniCols)],y=mtrainb_ann[,-c(1:iniCols)],size=c(n),maxit=it,outputActFunc="Act_Logistic")
      }
      dt_model <- C5.0(form,data=dt_train,trials=t)
      rf_model <- randomForest(form,data=rf_train,ntree=500)
      svm_model = cmp_ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=trainb,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=kparam)
      knn_model=kknn(formula = form,train = knn_train,test = knn_test,k = 2*k-1,distance=2,kernel=mode,scale=FALSE)
      
      # Predictions for the multiple model
      
      ann_preds=as.vector(matrix(0,nrow(mtestb_ann),1))
      preds=predict(ann_model,mtestb_ann[,1:iniCols])
      for(p in 1:nrow(preds)){
        max_pred=max(preds[p,])
        for(q in 1:ncol(preds)){
          if(preds[p,q]==max_pred){
            ann_preds[p]=classZero+q-1
          }
        }
      }
      dt_preds=as.numeric(as.character(predict(dt_model,dt_test)))
      rf_preds=as.numeric(as.character(predict(rf_model,rf_test)))
      svm_preds=as.numeric(as.character(predict(svm_model,testb[,colnames(testb)!=out])))
      knn_preds=as.numeric(as.character(knn_model$fitted.values))
      
      predictions=cbind(ann_preds,dt_preds,rf_preds,svm_preds,knn_preds)
      colnames(predictions)=c("ANN","DT","RF","SVM","KNN")
      
      # Final predictions for the multiple model
      
      preds=as.vector(matrix(0,nrow(testb),1))
      
      for(j in 1:nrow(testb)){
        uniqv <- unique(predictions[j,])
        preds[j]=uniqv[which.max(tabulate(match(predictions[j,], uniqv)))]
      }
      
      preds=as.factor(preds)
      
      # Confusion matrices
      
      conf=table(preds,testb[,out])
      ann_conf=table(as.factor(ann_preds),testb[,out])
      dt_conf=table(as.factor(dt_preds),dt_test[,out])
      rf_conf=table(as.factor(rf_preds),rf_test[,out])
      svm_conf=table(as.factor(svm_preds),testb[,out])
      knn_conf=table(as.factor(knn_preds),knn_test[,out])
      
      # Calculating multiple model accuracy (mean recall)
      
      mm_mp=0
      
      for(j in colnames(conf)){
        if(sum(conf[,j])!=0&&sum(conf[rownames(conf)==j,])!=0){
          mm_mp=mm_mp+conf[j,j]/sum(conf[,j])
        }
      }
      
      mm_mp=mm_mp/ncol(conf)
      
      cat("Multiple model accuracy:",mm_mp*100,"%\n\n")
      
      # Calculating each technique accuracy
      
      ann_mp=0
      
      for(j in colnames(ann_conf)){
        if(sum(ann_conf[,j])!=0&&sum(ann_conf[rownames(ann_conf)==j,])!=0){
          ann_mp=ann_mp+ann_conf[j,j]/sum(ann_conf[,j])
        }
      }
      
      ann_mp=ann_mp/ncol(ann_conf)
      
      cat("ANN accuracy for n =",n,"and m =",m,":",ann_mp*100,"%\n\n")
      
      knn_mp=0
      
      for(j in colnames(knn_conf)){
        if(sum(knn_conf[,j])!=0&&sum(knn_conf[rownames(knn_conf)==j,])!=0){
          knn_mp=knn_mp+knn_conf[j,j]/sum(knn_conf[,j])
        }
      }
      
      knn_mp=knn_mp/ncol(knn_conf)
      
      cat("KNN accuracy for k =",2*k-1,":",knn_mp*100,"%\n\n")
      
      dt_mp=0
      
      for(j in colnames(dt_conf)){
        if(sum(dt_conf[,j])!=0&&sum(dt_conf[rownames(dt_conf)==j,])!=0){
          dt_mp=dt_mp+dt_conf[j,j]/sum(dt_conf[,j])
        }
      }
      
      dt_mp=dt_mp/ncol(dt_conf)
      
      cat("DT accuracy for t =",t,":",100*dt_mp,"%\n\n")
      
      rf_mp=0
      
      for(j in colnames(rf_conf)){
        if(sum(rf_conf[,j])!=0&&sum(rf_conf[rownames(rf_conf)==j,])!=0){
          rf_mp=rf_mp+rf_conf[j,j]/sum(rf_conf[,j])
        }
      }
      
      rf_mp=rf_mp/ncol(rf_conf)
      
      cat("RF accuracy:",100*rf_mp,"%\n\n")
      
      svm_mp=0
      
      for(j in colnames(svm_conf)){
        if(sum(svm_conf[,j])!=0&&sum(svm_conf[rownames(svm_conf)==j,])!=0){
          svm_mp=svm_mp+svm_conf[j,j]/sum(svm_conf[,j])
        }
      }
      
      svm_mp=svm_mp/ncol(svm_conf)
      
      cat("SVM accuracy:",100*svm_mp,"%\n\n")
      
      
      # Keeping multiple model accuracy
      
      kval[i,1]=mm_mp*100
      
      # Keeping multiple model conf table
      
      loconf[[length(loconf)+1]]=conf
      
      # Keeping ANN accuracy
      
      ann_kval[i,"accuracy"]=ann_mp*100
      
      # Keeping ANN iterantions, "n" and "m"
      
      ann_kval[i,"iterations"]=it
      ann_kval[i,"n"]=n
      ann_kval[i,"m"]=m
      
      # Keeping ANN conf table
      
      ann_loconf[[length(ann_loconf)+1]]=ann_conf
      
      # Keeping DT accuracy
      
      dt_kval[i,"accuracy"]=dt_mp*100
      
      # Keeping DT trials
      
      dt_kval[i,"trials"]=t
      
      # Relevance analysis
      
      loimps[[length(loimps)+1]]=C5imp(dt_model,metric="splits") # Percentage of splits with the feature
      loimpu[[length(loimpu)+1]]=C5imp(dt_model,metric="usage") # Percentage of objects that uses the feature
      
      # Keeping DT conf table
      
      dt_loconf[[length(dt_loconf)+1]]=dt_conf
      
      # Keeping RF accuracy
      
      rf_kval[i,"accuracy"]=rf_mp*100
      
      # Saving importance vector in a list
      
      loimp[[length(loimp)+1]]=rf_model$importance
      
      # Keeping RF conf table
      
      rf_loconf[[length(rf_loconf)+1]]=rf_conf
      
      # Keeping SVM accuracy
      
      svm_kval[i,"accuracy"]=svm_mp*100
      
      # Keeping SVM conf table
      
      svm_loconf[[length(svm_loconf)+1]]=svm_conf
      
      # Keeping KNN accuracy
      
      knn_kval[i,"accuracy"]=knn_mp*100
      
      # Keeping KNN "k"
      
      knn_kval[i,"k"]=2*k-1
      
      # Keeping KNN conf table
      
      knn_loconf[[length(knn_loconf)+1]]=knn_conf
    }
    
    # Determining kparam
    
    if(svmMode=="polydot"){
      kparam=list(0,0,0)
      for(j in (length(lokpar)-9):length(lokpar)){
        kparam[[1]]=kparam[[1]]+lokpar[[j]][1]
        kparam[[2]]=kparam[[2]]+lokpar[[j]][2]
        kparam[[3]]=kparam[[3]]+lokpar[[j]][3]
      }
      kparam[[1]]=round(kparam[[1]]/10)
      kparam[[2]]=round(kparam[[2]]/10)
      kparam[[3]]=round(kparam[[3]]/10)
      
      lokparm[[length(lokparm)+1]]=c(kparam[[1]],kparam[[2]],kparam[[3]])
    }else{
      kparam="automatic"
    }
    
    # Adding kval to the list lokval
    
    lokval[[length(lokval)+1]]=kval
    
    # Adding mean to lokvalm
    
    lokvalm[[length(lokvalm)+1]]=mean(kval[,1])
    
    # Adding standard deviation to lokvalsd
    
    lokvalsd[[length(lokvalsd)+1]]=sd(kval[,1])
    
    # Creating mean conf tables
    
    if(out == "SBTn"){
      loconfm[[length(loconfm)+1]]=matrix(0,9,9)
      rownames(loconfm[[length(loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      colnames(loconfm[[length(loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      
      ann_loconfm[[length(ann_loconfm)+1]]=matrix(0,9,9)
      rownames(ann_loconfm[[length(ann_loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      colnames(ann_loconfm[[length(ann_loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      
      dt_loconfm[[length(dt_loconfm)+1]]=matrix(0,9,9)
      rownames(dt_loconfm[[length(dt_loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      colnames(dt_loconfm[[length(dt_loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      
      rf_loconfm[[length(rf_loconfm)+1]]=matrix(0,9,9)
      rownames(rf_loconfm[[length(rf_loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      colnames(rf_loconfm[[length(rf_loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      
      knn_loconfm[[length(knn_loconfm)+1]]=matrix(0,9,9)
      rownames(knn_loconfm[[length(knn_loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      colnames(knn_loconfm[[length(knn_loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      
      svm_loconfm[[length(svm_loconfm)+1]]=matrix(0,9,9)
      rownames(svm_loconfm[[length(svm_loconfm)]])=c("1","2","3","4","5","6","7","8","9")
      colnames(svm_loconfm[[length(svm_loconfm)]])=c("1","2","3","4","5","6","7","8","9")
    }
    else{
      loconfm[[length(loconfm)+1]]=matrix(0,8,8)
      rownames(loconfm[[length(loconfm)]])=c("0","1","2","3","4","5","6","7")
      colnames(loconfm[[length(loconfm)]])=c("0","1","2","3","4","5","6","7")
      
      ann_loconfm[[length(ann_loconfm)+1]]=matrix(0,8,8)
      rownames(ann_loconfm[[length(ann_loconfm)]])=c("0","1","2","3","4","5","6","7")
      colnames(ann_loconfm[[length(ann_loconfm)]])=c("0","1","2","3","4","5","6","7")
      
      dt_loconfm[[length(dt_loconfm)+1]]=matrix(0,8,8)
      rownames(dt_loconfm[[length(dt_loconfm)]])=c("0","1","2","3","4","5","6","7")
      colnames(dt_loconfm[[length(dt_loconfm)]])=c("0","1","2","3","4","5","6","7")
      
      rf_loconfm[[length(rf_loconfm)+1]]=matrix(0,8,8)
      rownames(rf_loconfm[[length(rf_loconfm)]])=c("0","1","2","3","4","5","6","7")
      colnames(rf_loconfm[[length(rf_loconfm)]])=c("0","1","2","3","4","5","6","7")
      
      knn_loconfm[[length(knn_loconfm)+1]]=matrix(0,8,8)
      rownames(knn_loconfm[[length(knn_loconfm)]])=c("0","1","2","3","4","5","6","7")
      colnames(knn_loconfm[[length(knn_loconfm)]])=c("0","1","2","3","4","5","6","7")
      
      svm_loconfm[[length(svm_loconfm)+1]]=matrix(0,8,8)
      rownames(svm_loconfm[[length(svm_loconfm)]])=c("0","1","2","3","4","5","6","7")
      colnames(svm_loconfm[[length(svm_loconfm)]])=c("0","1","2","3","4","5","6","7")
    }
    
    # Adding the mean conf table to loconfm
    
    for(j in 1:10){
      for(r in rownames(loconf[[length(loconf)-j+1]])){
        for(c in colnames(loconf[[length(loconf)-j+1]])){
          loconfm[[length(loconfm)]][r,c]=loconfm[[length(loconfm)]][r,c]+loconf[[length(loconf)-j+1]][r,c]
        }
      }
    }
    
    loconfm[[length(loconfm)]]=loconfm[[length(loconfm)]]/10
    
    # Saving importance vector in a list
    
    loimpsm[[length(loimpsm)+1]]=as.data.frame(matrix(0,length(inp),1))
    rownames(loimpsm[[length(loimpsm)]])=inp
    for(at in inp){
      for(j in (length(loimps)-9):length(loimps)){
        loimpsm[[length(loimpsm)]][at,1]=loimpsm[[length(loimpsm)]][at,1]+as.numeric(as.character(loimps[[j]][at,1]))
      }
    }
    loimpsm[[length(loimpsm)]]=loimpsm[[length(loimpsm)]]/10
    
    # Saving importance vector in a list
    
    loimpum[[length(loimpum)+1]]=as.data.frame(matrix(0,length(inp),1))
    rownames(loimpum[[length(loimpum)]])=inp
    for(at in inp){
      for(j in (length(loimpu)-9):length(loimpu)){
        loimpum[[length(loimpum)]][at,1]=loimpum[[length(loimpum)]][at,1]+as.numeric(as.character(loimpu[[j]][at,1]))
      }
    }
    loimpum[[length(loimpum)]]=loimpum[[length(loimpum)]]/10
    
    # Saving importance vector in a list
    
    loimpm[[length(loimpm)+1]]=as.data.frame(matrix(0,length(inp),1))
    rownames(loimpm[[length(loimpm)]])=inp
    for(at in inp){
      for(j in (length(loimp)-9):length(loimp)){
        loimpm[[length(loimpm)]][at,1]=loimpm[[length(loimpm)]][at,1]+as.numeric(as.character(loimp[[j]][at,1]))
      }
    }
    loimpm[[length(loimpm)]]=loimpm[[length(loimpm)]]/10
    
    # Adding kval to the list lokval
    
    ann_lokval[[length(ann_lokval)+1]]=ann_kval
    
    # Adding mean to lokvalm
    
    ann_lokvalm[[length(ann_lokvalm)+1]]=mean(ann_kval[,"accuracy"])
    
    # Adding standard deviation to lokvalsd
    
    ann_lokvalsd[[length(ann_lokvalsd)+1]]=sd(ann_kval[,"accuracy"])
    
    # Adding the mean conf table to loconfm
    
    for(j in 1:10){
      for(r in rownames(ann_loconf[[length(ann_loconf)-j+1]])){
        for(c in colnames(ann_loconf[[length(ann_loconf)-j+1]])){
          ann_loconfm[[length(ann_loconfm)]][r,c]=ann_loconfm[[length(ann_loconfm)]][r,c]+ann_loconf[[length(ann_loconf)-j+1]][r,c]
        }
      }
    }
    
    ann_loconfm[[length(ann_loconfm)]]=ann_loconfm[[length(ann_loconfm)]]/10
    
    # Adding kval to the list lokval
    
    dt_lokval[[length(dt_lokval)+1]]=dt_kval
    
    # Adding mean to lokvalm
    
    dt_lokvalm[[length(dt_lokvalm)+1]]=mean(dt_kval[,"accuracy"])
    
    # Adding standard deviation to lokvalsd
    
    dt_lokvalsd[[length(dt_lokvalsd)+1]]=sd(dt_kval[,"accuracy"])
    
    # Adding the mean conf table to loconfm
    
    for(j in 1:10){
      for(r in rownames(dt_loconf[[length(dt_loconf)-j+1]])){
        for(c in colnames(dt_loconf[[length(dt_loconf)-j+1]])){
          dt_loconfm[[length(dt_loconfm)]][r,c]=dt_loconfm[[length(dt_loconfm)]][r,c]+dt_loconf[[length(dt_loconf)-j+1]][r,c]
        }
      }
    }
    
    dt_loconfm[[length(dt_loconfm)]]=dt_loconfm[[length(dt_loconfm)]]/10
    
    # Adding kval to the list lokval
    
    rf_lokval[[length(rf_lokval)+1]]=rf_kval
    
    # Adding mean to lokvalm
    
    rf_lokvalm[[length(rf_lokvalm)+1]]=mean(rf_kval[,"accuracy"])
    
    # Adding standard deviation to lokvalsd
    
    rf_lokvalsd[[length(rf_lokvalsd)+1]]=sd(rf_kval[,"accuracy"])
    
    # Adding the mean conf table to loconfm
    
    for(j in 1:10){
      for(r in rownames(rf_loconf[[length(rf_loconf)-j+1]])){
        for(c in colnames(rf_loconf[[length(rf_loconf)-j+1]])){
          rf_loconfm[[length(rf_loconfm)]][r,c]=rf_loconfm[[length(rf_loconfm)]][r,c]+rf_loconf[[length(rf_loconf)-j+1]][r,c]
        }
      }
    }
    
    rf_loconfm[[length(rf_loconfm)]]=rf_loconfm[[length(rf_loconfm)]]/10
    
    # Adding kval to the list lokval
    
    svm_lokval[[length(svm_lokval)+1]]=svm_kval
    
    # Adding mean to lokvalm
    
    svm_lokvalm[[length(svm_lokvalm)+1]]=mean(svm_kval[,"accuracy"])
    
    # Adding standard deviation to lokvalsd
    
    svm_lokvalsd[[length(svm_lokvalsd)+1]]=sd(svm_kval[,"accuracy"])
    
    # Adding the mean conf table to loconfm
    
    for(j in 1:10){
      for(r in rownames(svm_loconf[[length(svm_loconf)-j+1]])){
        for(c in colnames(svm_loconf[[length(svm_loconf)-j+1]])){
          svm_loconfm[[length(svm_loconfm)]][r,c]=svm_loconfm[[length(svm_loconfm)]][r,c]+svm_loconf[[length(svm_loconf)-j+1]][r,c]
        }
      }
    }
    
    svm_loconfm[[length(svm_loconfm)]]=svm_loconfm[[length(svm_loconfm)]]/10
    
    # Adding kval to the list lokval
    
    knn_lokval[[length(knn_lokval)+1]]=knn_kval
    
    # Adding mean to lokvalm
    
    knn_lokvalm[[length(knn_lokvalm)+1]]=mean(knn_kval[,"accuracy"])
    
    # Adding standard deviation to lokvalsd
    
    knn_lokvalsd[[length(knn_lokvalsd)+1]]=sd(knn_kval[,"accuracy"])
    
    # Adding the mean conf table to loconfm
    
    for(j in 1:10){
      for(r in rownames(knn_loconf[[length(knn_loconf)-j+1]])){
        for(c in colnames(knn_loconf[[length(knn_loconf)-j+1]])){
          knn_loconfm[[length(knn_loconfm)]][r,c]=knn_loconfm[[length(knn_loconfm)]][r,c]+knn_loconf[[length(knn_loconf)-j+1]][r,c]
        }
      }
    }
    
    knn_loconfm[[length(knn_loconfm)]]=knn_loconfm[[length(knn_loconfm)]]/10
    
    # Best "n"
    
    x=ann_kval[,"n"]
    z=table(as.vector(x))
    bn=as.numeric(names(z)[z == max(z)])[1]
    lon[[length(lon)+1]]=bn
    
    # Best "m"
    
    x=ann_kval[,"m"]
    z=table(as.vector(x))
    bm=as.numeric(names(z)[z == max(z)])[1]
    lom[[length(lom)+1]]=bm
    
    # Best "k"
    
    x=knn_kval[,1]
    z=table(as.vector(x))
    bk=as.numeric(names(z)[z == max(z)])[1]
    lokvalk[[length(lokvalk)+1]]=bk
    
    # Converting data into matrix
    
    mdata=as.matrix(data)
    
    # Removing Robertson's (1991) class 0
    
    if(out=="SBTn"){
      mdata=mdata[mdata[,out]!=0,]
    }
    
    # Normalization by rescaling
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdata[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdata[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdata)){
        t=(mdata[obj,inp[j]]-mini)/(maxi-mini)
        mdata[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
      }
    }
    
    # Statistical marks for pre-filtering
    
    q1=c()
    q3=c()
    
    for(class in sort(unique(mdata[,out]))){
      auxq1=c()
      auxq3=c()
      for(at in inp[inp!="Depth_m"]){
        
        # First quartile
        
        auxq1=append(auxq1,quantile(mdata[mdata[,out]==class,at])[2])
        
        # Third quartile
        
        auxq3=append(auxq3,quantile(mdata[mdata[,out]==class,at])[4])
        
      }
      q1=cbind(q1,auxq1)
      q3=cbind(q3,auxq3)
    }
    
    
    # Interquartil interval
    
    iq=q3-q1
    
    # Formating
    
    q1=t(as.matrix(q1))
    colnames(q1)=inp[inp!="Depth_m"]
    rownames(q1)=sort(unique(mdata[,out]))
    
    q3=t(as.matrix(q3))
    colnames(q3)=inp[inp!="Depth_m"]
    rownames(q3)=sort(unique(mdata[,out]))
    
    iq=t(as.matrix(iq))
    colnames(iq)=inp[inp!="Depth_m"]
    rownames(iq)=sort(unique(mdata[,out]))
    
    # Data cleaning
    
    removed=0
    idx=c()
    
    # Pre-filtering
    
    cat("\nPre-filtering\n")
    
    for(obj in 1:nrow(mdata)){
      class=as.character(mdata[obj,out])
      for(at in inp[inp!="Depth_m"]){
        if(mdata[obj,at]>q3[class,at]+1.5*iq[class,at]
           || mdata[obj,at]<q1[class,at]-1.5*iq[class,at]){
          if(length(idx)==0 || obj!=idx[length(idx)]){
            idx=append(idx,obj)
            #cat("Pre-filtered:",length(idx),"\n")
            #cat("Object:",obj,"\n\n")
          }
        }
      }
    }
    
    # Data frame of the data set
    
    data=as.data.frame(mdata)
    
    # Converting outputs of the data frames into factors
    
    data[,out]=as.factor(data[,out])
    
    # Filtering
    
    cat("\nFiltering\n")
    
    filt=0
    
    for(obj in 1:length(idx)){
      fitTrain <- kknn(formula=form,
                       train=data[-idx[obj],],
                       test=data[idx[obj],],
                       k=1,
                       distance=2,
                       kernel="rectangular",
                       scale=FALSE)
      
      pred=fitTrain$fitted.values
      
      filt=filt+1
      
      # Remove object if it was misclassified
      
      if(pred!=data[idx[obj],out]){
        train=data[-idx[obj],]
        idx=idx-1
        removed=removed+1
        #cat("Filtered:",removed,"\n\n")
        #cat("Pre-filtered object:",filt,"\n")
      }
    }
    
    # Training data set as matrix
    
    data[,out]=as.numeric(as.character(data[,out]))
    mdata=as.matrix(data)
    
    # Initializing sets for balanced training set
    
    mdatab=mdata
    
    # Proportion check
    
    cat("\nProportion check\n\n")
    
    prop=c()
    
    for(j in sort(unique(mdatab[,out]))){
      prop=append(prop,nrow(mdatab[mdatab[,out]==j,]))
      cat("Class", j, ":", nrow(mdatab[mdatab[,out]==j,]),"\n")
    }
    
    cat("\nBalancing\n\n")
    
    # Number of elements in the minority class
    
    minProp=min(prop)
    
    # Total number of elements by class
    
    nTot=max(1000,2*minProp)
    
    # Balancing
    
    for(j in sort(unique(mdatab[,out]))){
      mtrainClass=mdatab[mdatab[,out]==j,]
      numEl=nrow(mtrainClass)
      if(numEl>nTot){
        set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
        objIdx=sample(nrow(mtrainClass),numEl-nTot)
        mdatab=rbind(mdatab[mdatab[,out]!=j,],mtrainClass[-objIdx,])
      }
      else if(numEl<nTot){
        for(p in 1:(nTot-numEl)){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),length(inp)+1)
          obj=c()
          for(at in colnames(mdatab)){
            if(at==out){
              obj=append(obj,j)
            }else{
              obj=append(obj,mean(mtrainClass[objIdx,at]))
            }
          }
          mdatab=rbind(mdatab,obj)
        }
      }
      cat("Class", j, ":", nrow(mdatab[mdatab[,out]==j,]),"\n")
    }
    
    # Modifying with one-to-c (canonic) encoding
    
    classZero=min(unique(mdata[,out]))
    nclass=max(unique(mdata[,out]))
    iniCols=ncol(mdata)
    mdata_ann=mdata
    mdatab_ann=mdatab
    for(j in classZero:nclass){
      mdata_ann=cbind(mdata_ann,matrix(0,nrow(mdata_ann),1))
      colnames(mdata_ann)[length(colnames(mdata_ann))]=paste("c",as.character(j),sep="")
      mdatab_ann=cbind(mdatab_ann,matrix(0,nrow(mdatab_ann),1))
      colnames(mdatab_ann)[length(colnames(mdatab_ann))]=paste("c",as.character(j),sep="")
    }
    for(j in 1:nrow(mdata_ann)){
      mdata_ann[j,iniCols+mdata_ann[j,out]+1-classZero]=1
    }
    for(j in 1:nrow(mdatab_ann)){
      mdatab_ann[j,iniCols+mdatab_ann[j,out]+1-classZero]=1
    }
    mdata_ann=mdata_ann[,colnames(mdata_ann)!=out]
    mdatab_ann=mdatab_ann[,colnames(mdatab_ann)!=out]
    iniCols=iniCols-1
    
    # Normalization of balanced training set
    
    cat("\nANN balanced training set normalization\n\n")
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdatab_ann[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdatab_ann[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdatab_ann)){
        mdatab_ann[obj,inp[j]]=(mdatab_ann[obj,inp[j]]-mini)/(maxi-mini)
      }
    }
    
    # From matrix into dataframe
    
    data_ann=as.data.frame(mdata_ann)
    rownames(data_ann)=NULL
    
    datab_ann=as.data.frame(mdatab_ann)
    rownames(datab_ann)=NULL
    
    # Constructing the model
    
    cat("\nConstructing ANN model\n\n")
    
    it=mean(ann_kval[,"iterations"])
    
    if(bm!=0){
      ann_model = cmp_mlp(x=mdatab_ann[,c(1:iniCols)],y=mdatab_ann[,-c(1:iniCols)],size=c(bn,bm),maxit=it,outputActFunc="Act_Logistic")
    }else{
      ann_model = cmp_mlp(x=mdatab_ann[,c(1:iniCols)],y=mdatab_ann[,-c(1:iniCols)],size=c(bn),maxit=it,outputActFunc="Act_Logistic")
    }
    
    # Saving weights matrix
    
    ann_lowm[[length(ann_lowm)+1]]=ann_model$snnsObject$getCompleteWeightMatrix()
    
    # Normalization of balanced training set
    
    cat("\nSVM balanced training set normalization\n\n")
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdatab[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdatab[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdatab)){
        mdatab[obj,inp[j]]=(mdatab[obj,inp[j]]-mini)/(maxi-mini)
      }
    }
    
    # Data frame of test data set
    
    data=as.data.frame(mdata)
    
    # Data frame of the data sets for balanced training set
    
    datab=as.data.frame(mdatab)
    
    # Converting outputs of the data frames into factors
    
    data[,out]=as.factor(data[,out])
    
    datab[,out]=as.factor(datab[,out])
    
    cat("\nConstructing SVM model\n\n")
    
    # Constructing a general model
    
    svm_model=cmp_ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=datab,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=kparam)
    
    # Keeping model
    
    svm_lomodels[[length(svm_lomodels)+1]]=svm_model
  }
}
