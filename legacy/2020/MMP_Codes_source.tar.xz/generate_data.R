#Reading .csv file and saving the data in a variable
##############################################################################

path = file.path("metro.csv")
dataNet = read.table(path, header = TRUE, sep = ",", stringsAsFactor = FALSE)

# Package for 10-fold cross validation
##############################################################################

library(caret)

# Creating folds for the database without geological age

foldsNet=createFolds(dataNet$SBTn,k=10,list=TRUE,returnTrain=FALSE)

# Proportion check
##############################################################################

for(j in 1:10){
  
  # Selecting fold
  
  cat("Fold",j,"\n\n")
  
  testNet=dataNet[foldsNet[[j]],]
  
  # Percentage of elements by class for Robertson (1991)
  
  cat("Robertson (1991)\n\n")
  
  for(i in sort(unique(dataNet$SBTn))){
    cat("Class", i, ":", 100*nrow(testNet[testNet$SBTn==i,])/nrow(dataNet[dataNet$SBTn==i,]),"\n")
  }
  
  cat("\n")
  
  # Percentage of elements by class for Robertson (2016)
  
  cat("Robertson (2016)\n\n")
  
  for(i in sort(unique(dataNet$MSBTn))){
    cat("Class", i, ":", 100*nrow(testNet[testNet$MSBTn==i,])/nrow(dataNet[dataNet$MSBTn==i,]),"\n")
  }
  
  cat("\n")
  
}

# Defining validation sets for each test stage without replacement
##############################################################################

# Vector with the chosen folds in sequence

validFolds=c()

# Vector with the picking options

pick=1:10

for(j in 1:10){
  
  # Selecting test fold
  
  cat("Test fold:",j,"\n\n")
  
  # Setting seed for sampling
  
  set.seed(NULL)
  
  # Sampling a fold for validation
  
  if(j<10){
    
    # Choosing some unchosen fold
    
    f=sample(pick[pick!=j],1)
    
    # Excluding chosen fold from the picking options
    
    pick=pick[pick!=f]
    
    # Keeping the fold identification
    
    validFolds=append(validFolds,f)
    
    # Print the choice
    
    cat("-> Validation fold:",f,"\n\n")
    
  }else{
    
    # Choosing the only unchosen fold remaining
    
    f=pick[1]
    
    # Excluding the last fold from the picking options
    
    pick=pick[pick!=f]
    
    # Keeping the fold identification
    
    validFolds=append(validFolds,f)
    
    # Print the last fold
    
    cat("-> Validation fold:",f,"\n\n")
    
  }
}

# Show the chosen folds in sequence

show(validFolds)

# Saving environment in a variable

save.image("data.RData")